-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : gztravel
-- 
-- Part : #1
-- Date : 2014-11-30 11:12:14
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `activities`
-- -----------------------------
DROP TABLE IF EXISTS `activities`;
CREATE TABLE `activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jq_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(45) NOT NULL,
  `special` text COMMENT '活动特色',
  `address` varchar(100) DEFAULT NULL COMMENT '详细地址',
  `starttime` time DEFAULT '00:00:00',
  `endtime` time DEFAULT '00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_activities_1` (`jq_id`),
  CONSTRAINT `FK_activities_1` FOREIGN KEY (`jq_id`) REFERENCES `jingqu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='特色活动';


-- -----------------------------
-- Table structure for `admin`
-- -----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(80) NOT NULL COMMENT '用户名',
  `password` varchar(64) NOT NULL COMMENT '密码',
  `logintime` int(10) DEFAULT NULL COMMENT '登陆时间',
  `islock` int(10) unsigned NOT NULL COMMENT '是否禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='管理员用户';

-- -----------------------------
-- Records of `admin`
-- -----------------------------
INSERT INTO `admin` VALUES ('8', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1417317108', '0');
INSERT INTO `admin` VALUES ('10', 'shenzhenlong1203', 'e10adc3949ba59abbe56e057f20f883e', '1417266450', '0');
INSERT INTO `admin` VALUES ('11', 'shenzhenlong1202', 'a7cb81bf4bce0073ac44b5d718d33ee6', '1417317122', '0');

-- -----------------------------
-- Table structure for `areaservice`
-- -----------------------------
DROP TABLE IF EXISTS `areaservice`;
CREATE TABLE `areaservice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL COMMENT '酒店，饭店，农家乐等',
  `level` int(10) unsigned DEFAULT NULL,
  `islock` int(10) unsigned NOT NULL COMMENT '是否禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='区域服务';

-- -----------------------------
-- Records of `areaservice`
-- -----------------------------
INSERT INTO `areaservice` VALUES ('1', '酒店', '1', '0');
INSERT INTO `areaservice` VALUES ('3', '农家乐', '1', '0');
INSERT INTO `areaservice` VALUES ('4', '饭店', '1', '0');
INSERT INTO `areaservice` VALUES ('5', '商店', '1', '0');
INSERT INTO `areaservice` VALUES ('6', '加油站', '2', '0');
INSERT INTO `areaservice` VALUES ('7', '停车场', '1', '0');
INSERT INTO `areaservice` VALUES ('8', ' 银行', '2', '0');
INSERT INTO `areaservice` VALUES ('9', '取款机', '2', '0');

-- -----------------------------
-- Table structure for `chi`
-- -----------------------------
DROP TABLE IF EXISTS `chi`;
CREATE TABLE `chi` (
  `id` int(10) unsigned NOT NULL,
  `as_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '区域服务ID',
  `jq_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '景区ID',
  `name` varchar(80) NOT NULL COMMENT '吃的名字',
  `title` text COMMENT '简介',
  `comment` text COMMENT '详细描述',
  `address` varchar(100) DEFAULT NULL COMMENT '地址',
  `tel` varchar(45) DEFAULT NULL COMMENT '电话',
  `recommend` int(10) unsigned DEFAULT NULL COMMENT '推荐等级',
  `starttime` time DEFAULT '00:00:00' COMMENT '营业开始时间',
  `endtime` time DEFAULT '00:00:00' COMMENT '营业结束时间',
  `isnet` int(10) unsigned DEFAULT NULL COMMENT '是否有网路',
  `picurl` varchar(100) DEFAULT NULL COMMENT '图片地址',
  `videourl` varchar(100) DEFAULT NULL COMMENT '音频地址',
  `pointlng` double NOT NULL COMMENT '经度',
  `pointlat` double NOT NULL COMMENT '纬度',
  `islock` int(10) unsigned NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `FK_chi_1` (`jq_id`),
  KEY `FK_chi_2` (`as_id`),
  CONSTRAINT `FK_chi_1` FOREIGN KEY (`jq_id`) REFERENCES `jingqu` (`id`),
  CONSTRAINT `FK_chi_2` FOREIGN KEY (`as_id`) REFERENCES `areaservice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='吃';


-- -----------------------------
-- Table structure for `jingdian`
-- -----------------------------
DROP TABLE IF EXISTS `jingdian`;
CREATE TABLE `jingdian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jq_id` int(10) unsigned NOT NULL COMMENT '景区ID',
  `name` varchar(80) NOT NULL COMMENT '景点名',
  `title` text COMMENT '简介',
  `comment` text COMMENT '详细描述',
  `recommend` int(10) unsigned NOT NULL COMMENT '推荐等级',
  `pay` double DEFAULT NULL COMMENT '景点门票',
  `picurl` varchar(100) DEFAULT NULL COMMENT '图片地址',
  `videourl` varchar(100) DEFAULT NULL COMMENT '音频地址',
  `pointlng` double NOT NULL COMMENT '经度',
  `pointlat` double NOT NULL COMMENT '纬度',
  `islock` int(10) unsigned NOT NULL COMMENT '是否锁定',
  PRIMARY KEY (`id`),
  KEY `FK_jingdian_1` (`jq_id`),
  CONSTRAINT `FK_jingdian_1` FOREIGN KEY (`jq_id`) REFERENCES `jingqu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='景点';


-- -----------------------------
-- Table structure for `jingqu`
-- -----------------------------
DROP TABLE IF EXISTS `jingqu`;
CREATE TABLE `jingqu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT '景区名',
  `title` text NOT NULL COMMENT '简介',
  `comment` text NOT NULL COMMENT '详细描述',
  `recommend` int(10) unsigned NOT NULL COMMENT '推荐等级',
  `address` varchar(100) DEFAULT NULL COMMENT '地址',
  `tel` varchar(100) DEFAULT NULL COMMENT '电话',
  `starttime` time NOT NULL DEFAULT '00:00:00' COMMENT '营业开始时间',
  `endtime` time NOT NULL DEFAULT '00:00:00' COMMENT '营业结束时间',
  `evgcost` double DEFAULT NULL COMMENT '人均消费',
  `traffic` varchar(100) NOT NULL COMMENT '交通',
  `pay` double NOT NULL COMMENT '门票',
  `picurl` varchar(300) DEFAULT NULL COMMENT '图片地址',
  `videourl` varchar(100) DEFAULT NULL COMMENT '语音地址',
  `pointlng` double NOT NULL COMMENT '经度',
  `pointlat` double NOT NULL COMMENT '纬度',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='景区';


-- -----------------------------
-- Table structure for `meishi`
-- -----------------------------
DROP TABLE IF EXISTS `meishi`;
CREATE TABLE `meishi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chi_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '吃的ID',
  `name` varchar(45) NOT NULL DEFAULT '' COMMENT '美食名',
  `title` text COMMENT '简介',
  `comment` text COMMENT '详细描述',
  `recommend` int(10) unsigned NOT NULL COMMENT '推荐等级',
  `picurl` varchar(100) DEFAULT NULL COMMENT '图片地址',
  `videourl` varchar(100) DEFAULT NULL COMMENT '音频地址',
  `islock` int(10) unsigned NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `FK_meishi_1` (`chi_id`),
  CONSTRAINT `FK_meishi_1` FOREIGN KEY (`chi_id`) REFERENCES `chi` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='美食';


-- -----------------------------
-- Table structure for `news`
-- -----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` text COMMENT '新闻标题',
  `comment` text COMMENT '新闻内容',
  `updatetime` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '变更时间',
  `islock` int(11) unsigned DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='新闻';


-- -----------------------------
-- Table structure for `picture`
-- -----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jq_id` int(10) unsigned DEFAULT NULL COMMENT '景区ID',
  `title` text COMMENT '图片简介',
  `state` int(10) unsigned DEFAULT '0' COMMENT '审核是否通过',
  `uptime` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '上传时间',
  `islock` int(10) unsigned DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `FK_picture_1` (`jq_id`),
  CONSTRAINT `FK_picture_1` FOREIGN KEY (`jq_id`) REFERENCES `jingqu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='拍';


-- -----------------------------
-- Table structure for `shop`
-- -----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `as_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '区域服务ID',
  `jq_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT '商店名字',
  `title` text COMMENT '简介',
  `comment` text COMMENT '详细描述',
  `address` varchar(100) DEFAULT NULL COMMENT '地址',
  `tel` varchar(45) DEFAULT NULL COMMENT '电话',
  `recommend` int(10) unsigned DEFAULT NULL COMMENT '推荐等级',
  `starttime` time DEFAULT '00:00:00' COMMENT '营业开始时间',
  `endtime` time DEFAULT '00:00:00' COMMENT '营业结束时间',
  `picurl` varchar(100) DEFAULT NULL COMMENT '图片地址',
  `videourl` varchar(100) DEFAULT NULL COMMENT '音频地址',
  `pointlng` double NOT NULL COMMENT '经度',
  `pointlat` double NOT NULL COMMENT '纬度',
  `islock` int(10) unsigned NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `FK_shop_1` (`as_id`),
  KEY `FK_shop_2` (`jq_id`),
  CONSTRAINT `FK_shop_1` FOREIGN KEY (`as_id`) REFERENCES `areaservice` (`id`),
  CONSTRAINT `FK_shop_2` FOREIGN KEY (`jq_id`) REFERENCES `jingqu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商店';


-- -----------------------------
-- Table structure for `techan`
-- -----------------------------
DROP TABLE IF EXISTS `techan`;
CREATE TABLE `techan` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商店ID',
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT '名称',
  `title` text COMMENT '简介',
  `comment` text COMMENT '详细介绍',
  `recommend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '推荐等级',
  `picurl` varchar(100) NOT NULL DEFAULT '' COMMENT '图片路径',
  `islock` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `FK_techan_1` (`shop_id`),
  CONSTRAINT `FK_techan_1` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='特产';


-- -----------------------------
-- Table structure for `zhu`
-- -----------------------------
DROP TABLE IF EXISTS `zhu`;
CREATE TABLE `zhu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `as_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '区域服务ID',
  `jq_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT '住的名字',
  `title` text COMMENT '简介',
  `comment` text COMMENT '详细描述',
  `address` varchar(100) DEFAULT NULL COMMENT '地址',
  `tel` varchar(45) DEFAULT NULL COMMENT '电话',
  `recommend` int(10) unsigned DEFAULT NULL COMMENT '推荐等级',
  `starttime` time DEFAULT '00:00:00' COMMENT '入住时间',
  `endtime` time DEFAULT '00:00:00' COMMENT '退房时间',
  `isnet` int(10) unsigned DEFAULT NULL COMMENT '是否有网路',
  `picurl` varchar(100) DEFAULT NULL COMMENT '图片地址',
  `videourl` varchar(100) DEFAULT NULL COMMENT '音频地址',
  `pointlng` double NOT NULL COMMENT '经度',
  `pointlat` double NOT NULL COMMENT '纬度',
  `islock` int(10) unsigned NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `FK_zhu_1` (`as_id`),
  KEY `FK_zhu_2` (`jq_id`),
  CONSTRAINT `FK_zhu_1` FOREIGN KEY (`as_id`) REFERENCES `areaservice` (`id`),
  CONSTRAINT `FK_zhu_2` FOREIGN KEY (`jq_id`) REFERENCES `jingqu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='住';

